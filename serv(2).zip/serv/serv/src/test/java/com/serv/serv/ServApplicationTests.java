package com.serv.serv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServApplicationTests {

	@Test
	void contextLoads() {
	}

}
