package com.serv.serv;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

@Component
@FeignClient(name ="VALIDATION-SERVICE")
//@Headers({"authorization", "Bearer qwerty"})
public interface service {
    @GetMapping(value="/validate")
    boolean val(@RequestHeader("authorization") String token);

}
