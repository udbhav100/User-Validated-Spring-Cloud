package com.serv.serv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cloud.gateway.route.CachingRouteLocator;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import reactor.core.publisher.Flux;

import java.util.List;

@SpringBootApplication
@EnableFeignClients
@EnableEurekaClient
@EnableAutoConfiguration
@ComponentScan
public class ServApplication {
	private static ApplicationContext applicationContext;

	public static void main(String[] args) {

		SpringApplication.run(ServApplication.class, args);
		applicationContext = new AnnotationConfigApplicationContext(ServApplication.class);
		for (String beanName : applicationContext.getBeanDefinitionNames()) { System.out.println(beanName); }
	}

//	@Bean
//	@Primary
//	@ConditionalOnMissingBean(name = "cachedCompositeRouteLocator")
//	public RouteLocator cachedCompositeRouteLocator(List<RouteLocator> routeLocators) {
//		return new CachingRouteLocator(new CustomCompositeRouteLocator(Flux.fromIterable(routeLocators), ignoreServiceIds));
//	}



}
