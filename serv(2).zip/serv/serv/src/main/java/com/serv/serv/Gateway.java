package com.serv.serv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cloud.gateway.actuate.GatewayControllerEndpoint;
import org.springframework.cloud.gateway.config.GatewayProperties;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.filter.factory.GatewayFilterFactory;
import org.springframework.cloud.gateway.handler.FilteringWebHandler;
import org.springframework.cloud.gateway.handler.RoutePredicateHandlerMapping;
import org.springframework.cloud.gateway.handler.predicate.RoutePredicateFactory;
import org.springframework.cloud.gateway.route.*;
import org.springframework.context.annotation.Bean;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import reactor.core.publisher.Flux;

import java.util.List;

@Configuration
public class Gateway {
    @Autowired
    service service1;

    @Bean
    public RouteLocator myRoutes(RouteLocatorBuilder builder) {
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println(service1);
        System.out.println();
        System.out.println();
        return builder.routes()
                .route("r1",
                        r -> r  .host("**localhost:8081")
                                .and()
                                .path("/location/**")
                                .filters(f -> f.filter(new AuthFilter(service1)))
                                .uri("lb://DESTINATION-SERVICE"))

                //Routing the request to -> http://localhost:8082/...

                .build();

    }





}
