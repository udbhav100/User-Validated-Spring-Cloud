package com.serv.serv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class AuthFilter extends AbstractGatewayFilterFactory<AuthFilter.Config> implements GatewayFilter {
    private service service;

    public AuthFilter() {
        super(Config.class);
    }

    public AuthFilter(service service1){
        this.service=service1;


    }

    //    //@RequestMapping("/validate")
//    public boolean val1(String authorizationHeader){
//
//        return service1.val(authorizationHeader);
//    }
//
//    private boolean isAuthorizationValid(String authorizationHeader) {
//
//        service service1 = null;
//        return true;
//    }

    private Mono<Void> onError(ServerWebExchange exchange, String err, HttpStatus httpStatus)  {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(httpStatus);
        return response.setComplete();
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        HttpHeaders headers = exchange.getRequest().getHeaders();
        //Set<String> headerNames = headers.keySet();


//        headerNames.forEach((header) -> {
//            System.out.println(header + " " + headers.get(header));
//        });

       // try {
            List<String> token = headers.get("authorization");
            System.out.println(token.get(0));
            System.out.println(service);
            //System.out.println();


            if (this.service.val(token.get(0))) {
                return this.onError(exchange,"Invalid Token!",HttpStatus.FORBIDDEN);
            }
       // }
        //catch (NullPointerException e){
        //    return this.onError(exchange,"No Token!",HttpStatus.FORBIDDEN);
        //}
        return chain.filter(exchange);
    }


    @Override
    public GatewayFilter apply(Config config) {
        return null;
    }



    public static class Config {
    }
}
