package com.serv.serv;

import org.springframework.stereotype.Component;

@Component
public class dummy {

}
